/**
 * Executable evidence for verified-hidden-gold candidate:
 *   [11059] parseRefreshTokenResponse (credential-sync path) drops expiry metadata and
 *   overwrites refresh_token with the literal string "refresh_token".
 *
 * Runs against the REAL post-PR file (packages/app-store/_utils/oauth/parseRefreshTokenResponse.ts).
 * Expected: FAIL on the PR head, PASS with the minimal fix in fix.patch.
 */
import { expect, test } from "vitest";
import { z } from "zod";

// The credential-sync branch is gated on these env-derived constants (packages/lib/constants.ts),
// so set them BEFORE the module (and therefore constants) is imported.
process.env.CALCOM_WEBHOOK_SECRET = "whsec_test";
process.env.CALCOM_APP_CREDENTIAL_ENCRYPTION_KEY = "enc_key_test";
process.env.CALCOM_CREDENTIAL_SYNC_ENDPOINT = "https://sync.example.test/credentials";

const perAppSchema = z.object({
  access_token: z.string(),
  refresh_token: z.string().optional(),
  expires_in: z.number().optional(),
});

test("[11059] credential-sync path preserves expiry + refresh_token metadata", async () => {
  const { default: parseRefreshTokenResponse } = await import(
    "./parseRefreshTokenResponse"
  );

  const upstream = {
    access_token: "at-123",
    refresh_token: "rt-456",
    expires_in: 3600,
    token_type: "Bearer",
  };

  const result: any = parseRefreshTokenResponse(upstream, perAppSchema);
  expect(result.success).toBe(true);

  // Baseline: the access token itself always survives.
  expect(result.data.access_token).toBe("at-123");

  // The defect: the minimum sync schema strips unknown keys, so expiry metadata is lost
  // (consumers then re-refresh on every request), and the missing refresh_token is replaced
  // by the literal placeholder string.
  expect(result.data.expires_in).toBe(3600);
  expect(result.data.refresh_token).toBe("rt-456");
});
